// PLACEHOLDER — replace by running:
//
//   dart pub global activate flutterfire_cli
//   flutterfire configure --project=<your-firebase-project-id>
//
// The FlutterFire CLI regenerates this file with the real
// `DefaultFirebaseOptions` for every platform you select.

import 'package:firebase_core/firebase_core.dart' show FirebaseOptions;

class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    throw UnsupportedError(
      'Firebase is not configured yet. Run `flutterfire configure` to '
      'generate lib/firebase_options.dart for this project.',
    );
  }
}
